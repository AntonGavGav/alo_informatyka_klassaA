The best option in my opinion is to use **linked list** as it has a dynamic size and a constant time insertion(unlike the dynamic arrays).
Also linked lists are memory efficient and accessing and removing the top element happens in a constant time which is exactly what we need
To use linked list as a stack we can make the upcoming element a head of the list and that will do the job

you can also implement stack using two queues